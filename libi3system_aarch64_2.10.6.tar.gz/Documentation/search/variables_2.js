var searchData=
[
  ['edgelevel',['edgeLevel',['../structi3_1_1_i_m_g_p_r_o_c_p_r_m_s.html#a0c26eec89bd038af5efeb295a11fa5c9',1,'i3::IMGPROCPRMS']]],
  ['enable',['enable',['../structi3_1_1_i_m_g_p_r_o_c_p_r_m_s.html#a9d894db57fb290e17ba8a5f9cf2b781f',1,'i3::IMGPROCPRMS']]]
];
