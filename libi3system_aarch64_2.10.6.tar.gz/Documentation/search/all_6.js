var searchData=
[
  ['hotplug_5fcallback_5ffunc',['hotplug_callback_func',['../i3system___t_e_8h.html#aa0f04b7dddbcbc86d82d2e7aabf9bf90',1,'i3']]]
];
