var searchData=
[
  ['recvimage',['RecvImage',['../classi3_1_1_t_e___a.html#ad41b4963f01865c40f51ebc7d463252e',1,'i3::TE_A::RecvImage(unsigned short *pRecvImage, bool _AGC_On)'],['../classi3_1_1_t_e___a.html#ae5684fb420491eaaf9fea1a2cedfb976',1,'i3::TE_A::RecvImage(unsigned short *img_buf, float temp_min, float temp_max)'],['../classi3_1_1_t_e___a.html#a3cefc65f720cd82a05f11c96ccfc07af',1,'i3::TE_A::RecvImage(unsigned short *dst)'],['../classi3_1_1_t_e___b.html#adbd93785a3870e4576130da34753266a',1,'i3::TE_B::RecvImage(float *pRecvImage)'],['../classi3_1_1_t_e___b.html#a8b0852dbd196be4154d9a1f6ac1bd5f4',1,'i3::TE_B::RecvImage(unsigned short *pRecvImage)'],['../classi3_1_1_t_e___b.html#ad4f2eabf3fd87d1174c935b713accf1f',1,'i3::TE_B::RecvImage(void *dst)']]],
  ['resetmainboard',['ResetMainBoard',['../classi3_1_1_t_e___a.html#a54c0b989cc85c74123a66c4301c48e17',1,'i3::TE_A']]]
];
