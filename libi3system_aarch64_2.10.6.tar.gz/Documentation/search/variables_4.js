var searchData=
[
  ['ncoreid',['nCoreID',['../structi3_1_1_t_e_scan_data.html#ad016816a78c1ef9cfaaa8f6942c66ea6',1,'i3::TEScanData']]],
  ['nprodver',['nProdVer',['../structi3_1_1_t_e_scan_data.html#a3a2593e37332e03e9822a72241563533',1,'i3::TEScanData']]],
  ['nusbnum',['nUsbNum',['../structi3_1_1_usb_state.html#a957d99642f3b7261c98c1f8134e84e42',1,'i3::UsbState']]],
  ['nusbstate',['nUsbState',['../structi3_1_1_usb_state.html#a29cec08c87de98857935722cabf8948f',1,'i3::UsbState']]]
];
