var searchData=
[
  ['getagclimitgain',['GetAgcLimitGain',['../classi3_1_1_t_e___a.html#ab39c75ca4dfd31e907bdcbbeaaec4e12',1,'i3::TE_A']]],
  ['getfpatemp',['GetFpaTemp',['../classi3_1_1_t_e___a.html#adfe721102b6b229c16cad97d3c5a0355',1,'i3::TE_A::GetFpaTemp()'],['../classi3_1_1_t_e___b.html#a600c8c451fe0600581e06a926501a3b3',1,'i3::TE_B::GetFpaTemp()'],['../classi3_1_1_t_e___b.html#a6f989e993c22cca1d375fe3a195df556',1,'i3::TE_B::GetFPATemp()']]],
  ['getframetemperature',['getFrameTemperature',['../classi3_1_1_t_e___b.html#af10825cf9c3aa37d56463e29216aa311',1,'i3::TE_B']]],
  ['getid',['GetID',['../classi3_1_1_t_e___a.html#a3016718a0f9de3dbf0da8c878735a730',1,'i3::TE_A']]],
  ['getimageheight',['GetImageHeight',['../classi3_1_1_t_e___a.html#aad258310e0cd3539bdab0face8904698',1,'i3::TE_A::GetImageHeight()'],['../classi3_1_1_t_e___b.html#a4ec855ef0408e6e0a4673d604c676aa8',1,'i3::TE_B::GetImageHeight()']]],
  ['getimagewidth',['GetImageWidth',['../classi3_1_1_t_e___a.html#a6575afd3c0ad26b7c1afd95758f3d3c2',1,'i3::TE_A::GetImageWidth()'],['../classi3_1_1_t_e___b.html#a17bd281ae1c0e0552fd06a7dbd53ac89',1,'i3::TE_B::GetImageWidth()']]],
  ['getsetting',['GetSetting',['../classi3_1_1_t_e___a.html#a8de8bb29167fb61a0dfe135de483fbd1',1,'i3::TE_A']]],
  ['getshutterpt100rawvalue',['GetShutterPt100RawValue',['../classi3_1_1_t_e___a.html#a779d65af616fb2b9b41233a28fe9a973',1,'i3::TE_A']]],
  ['getshutterpt100temp',['GetShutterPt100Temp',['../classi3_1_1_t_e___a.html#aecbc7ea4188b1eb22387b83fee967cda',1,'i3::TE_A']]]
];
