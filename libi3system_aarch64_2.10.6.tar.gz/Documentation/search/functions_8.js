var searchData=
[
  ['updatedead',['UpdateDead',['../classi3_1_1_t_e___b.html#a36c24ec7bd63a33f599fcfb7411ade42',1,'i3::TE_B::UpdateDead()'],['../classi3_1_1_t_e___b.html#a8e4bf2a63e09c104af8d50fb69de508a',1,'i3::TE_B::UpdateDead(const char *path)']]]
];
