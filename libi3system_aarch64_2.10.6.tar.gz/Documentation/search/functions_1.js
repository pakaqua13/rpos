var searchData=
[
  ['calcentiretemp',['CalcEntireTemp',['../classi3_1_1_t_e___b.html#aa50129496a7edeebcd69af930a86edef',1,'i3::TE_B']]],
  ['calctemp',['CalcTemp',['../classi3_1_1_t_e___a.html#aad352372be9827de1a26d701701db528',1,'i3::TE_A::CalcTemp(unsigned short _x, unsigned short _y)'],['../classi3_1_1_t_e___a.html#ae040466dc152b57a05671c7dc336df46',1,'i3::TE_A::CalcTemp(unsigned short *_pTempBuf)'],['../classi3_1_1_t_e___b.html#ab5f2c711823c2c334feb3cf045917c83',1,'i3::TE_B::CalcTemp()']]],
  ['clearhotplugcallback',['ClearHotplugCallback',['../i3system___t_e_8h.html#a6b44b890013ce1f745199f4fdca9a48c',1,'i3']]],
  ['closete',['CloseTE',['../classi3_1_1_t_e___a.html#a9fb4549417aa213abb0386c20b12ce7b',1,'i3::TE_A::CloseTE()'],['../classi3_1_1_t_e___b.html#afcdfa2b37ac3d305de0a0b1f17cba74c',1,'i3::TE_B::CloseTE()']]]
];
