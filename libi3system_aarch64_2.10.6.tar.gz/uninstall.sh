#!/bin/sh

rm /usr/local/lib/libi3*
rm -rf /usr/local/include/i3system
rm /etc/udev/rules.d/i3Vendor.rules
